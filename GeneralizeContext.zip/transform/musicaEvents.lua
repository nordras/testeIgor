-- Por padrao o arquivo começar com letras minusculas

local musicaEvents = {}

musicaEvents.START = "musicaEventsStart"
musicaEvents.STOP = "musicaEventsStop"
musicaEvents.RESUME = "musicaEventsResume"
musicaEvents.SUSPEND = "musicaEventsSuspend"
musicaEvents.PROXY_EVENT = "musicaEventsProxyEvent"
musicaEvents.SCENE_STARTED = "musicaEventsSceneStarted"
musicaEvents.SCENE_EXITED = "musicaEventsSceneExited"

return musicaEvents
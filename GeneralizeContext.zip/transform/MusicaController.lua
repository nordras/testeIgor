local MusicaController = {}
local Controller = require "Controller"

--extende o MusicaController ao controller.lua
Controller:generalize(MusicaController)

-- importa metodos ao Musica
MusicaController.PM = require "MusicaPM"
MusicaController.events = require "MusicaEvents"
MusicaController.context = "Musica"

MusicaController:prepare()

return MusicaController

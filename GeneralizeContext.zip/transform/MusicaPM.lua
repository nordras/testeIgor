local MusicaPM = {}
local LanguageSelector  = require "LanguageSelector"
local PM = require "PM"

PM:generalize(MusicaPM)

function MusicaPM:changeLanguage(newLanguage)
	print("MusicaPM: newLanguage")
	LanguageSelector:changeLanguage(newLanguage)
	return true
end

function MusicaPM:getScene()
	return "MusicaScene"
end

function MusicaPM:buyApp()
	print("musicaPM: BuyApp")
	self.buyed = true
end

return MusicaPM
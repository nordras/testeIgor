local storyboard = require "storyboard"
local MusicaView = require "MusicaView"
local Button = require "Button"
local BLAudio = require "BLAudio"
local LanguageSelector = require "LanguageSelector"
local leituraStates = require "leituraStates"

local scene = {}
local Scene = require"Scene"
Scene.scene:generalize(scene)
scene.name = "MusicaScene"
scene:prepare()

function scene:enter()

	storyboard.stage:toFront()	
end

function scene:create()
	-- Background e audio =======================
	self.trilha = BLAudio.newAudio("assets/audio/trilha.mp3",true)
	self:addAudioReference(name,self.trilha)
	
	self.bg = display.newImageRect ( self.view,"assets/img/background.png", 2600, 1536)
	self.bg:setReferencePoint(display.CenterReferencePoint)
	self.bg.x = display.contentCenterX
	self.bg.y = display.contentCenterY
	
	self.elementsCreated = true
	
	local myText = display.newText(self.view, "====== musica ======", 250, 500, native.systemFont, 50)
end

function scene:load() end

function scene:exit() end

function scene:sceneEnd()
	storyboard.purgeScene(self.name)
end

function scene:destroy() end


return scene
local MusicaView = {}

local storyboard = require "storyboard"
local globalEvent = require "globalEvent"
local View = require "View"
local MusicaPM = require "MusicaPM"

View:generalize(MusicaView)

MusicaView.events = require "musicaEvents"
MusicaView.sceneName = "MusicaScene"
MusicaView.animTransition = "fade"

MusicaView.viewStart = MusicaView.start

function MusicaView:start()
	print("Teste")
	self:viewStart()
	self:changeScene()
end

function MusicaView:goToIndice()
	print("musicaView: Indice")
	Runtime:dispatchEvent({name = globalEvent.CONTEXT_CHANGE,context = "Indice"})
end

function MusicaView:goToLeitura(nextState)
	print("musicaView: Sobre")
	Runtime:dispatchEvent({name = globalEvent.CONTEXT_CHANGE, context = "Sobre", state = nextState})
end

--TODO
function MusicaView:goToLeitura(nextState)
	print("musicaView: Pages")
	Runtime:dispatchEvent({name = globalEvent.CONTEXT_CHANGE, context = "Leitura", state = nextState})
end

function MusicaView:onClickPreviousBtn()
	print("musicaView:")
end

function MusicaView:goToLojinha()
	storyboard.showOverlay("LojinhaPopUp",
			{
				effect = "fade",
	    		time = 400,
   		 		params ={
        			sample_var = "anything",
	        		custom = "you want",
	        		data = "here"
   		 		}
			},
		true
	)
end
MusicaView:prepare()
return MusicaView
